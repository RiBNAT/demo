<?php
define("DB_HOST", "localhost");
define("DB_USER", "id19775165_abc");
define("DB_PASS", "PzR2vy?InT#4<0T8");
define("DB_NAME", "id19775165_mydb");
define("TITLE", "Blog with PHP OOP Project");
define("KEYWORDS", "PHP Tutorial,Java Tutorial,Oracle Database");
?>