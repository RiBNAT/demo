<!-- //date formating -->
<?php
class Format{
    public function formatDate($date){
    // return date('d-m-Y',strtotime($date));
    return date('F j,Y,g:i a',strtotime($date));
}
public function textShort($text,$limit=400){
$text=$text." ";
$text=substr($text,0,$limit);
//$text=substr($text,0,strpos($text," "));
$text=$text."...... ";
return $text;
}
//form validation
public function validation($data){
    $data=trim($data);//for remove space
    $data=stripcslashes($data);//for removing backslash and conver spacial character
    $data=htmlspecialchars($data);//removing html special character
    return $data;
}
public function title(){
$path=$_SERVER['SCRIPT_FILENAME'];
$title=basename($path,'.php');
if($title=='index'){
  $title='home';
}elseif($title=='About'){
    $title='About_Us';
}elseif($title=='Services'){
    $title='Services';
}elseif($title=='Skill'){
    $title='Skill';
}
elseif($title=='contact'){
    $title='contact';
}
return $title=ucwords($title);
}
}
?>