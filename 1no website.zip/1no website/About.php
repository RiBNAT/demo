<?php 
	include "inc/header.php";
?>

    <div class="contentsection clear">
        <div class="part1 clear">
            <div class="maincontent clear">
                <div class="about">
                    <h2>About Us</h2>
                    <img src="img/about.jpg" alt="">
                    <p>About me...Lorem, ipsum dolor sit amet consectetur adipisicing elit. Cupiditate, ipsa illo suscipit nemo saepe error hic optio mollitia ducimus magni animi quia vero, sint veritatis consectetur laboriosam dolorum! Molestiae reiciendis molestias, magni facere eos incidunt veritatis nemo saepe rerum dolorem expedita itaque delectus mollitia libero repellat excepturi magnam temporibus officia.</p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt ipsam placeat corporis voluptas soluta, qui dolor. Iste cupiditate nisi corrupti. Aliquid illo ea nostrum ipsa, ipsum aut rem impedit consequatur eligendi harum dolorem possimus ab eveniet temporibus, architecto numquam atque in placeat deleniti! Cum vitae, autem exercitationem voluptatem delectus odio.</p>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ipsam praesentium nemo, iusto fuga omnis dolorem quos. Optio, minima assumenda. Sed iste sequi voluptas officiis iusto similique animi cupiditate, repellat porro quos et neque quam vitae perferendis, aperiam cum assumenda dolor at deserunt deleniti fugiat excepturi? Possimus harum ab sequi sint?</p>
                </div>
                <div class="about">
                    <hr><br>
                    <img src="img/a.jpg" alt="">
                    <p>About me...Lorem, ipsum dolor sit amet consectetur adipisicing elit. Cupiditate, ipsa illo suscipit nemo saepe error hic optio mollitia ducimus magni animi quia vero, sint veritatis consectetur laboriosam dolorum! Molestiae reiciendis molestias, magni facere eos incidunt veritatis nemo saepe rerum dolorem expedita itaque delectus mollitia libero repellat excepturi magnam temporibus officia.</p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt ipsam placeat corporis voluptas soluta, qui dolor. Iste cupiditate nisi corrupti. Aliquid illo ea nostrum ipsa, ipsum aut rem impedit consequatur eligendi harum dolorem possimus ab eveniet temporibus, architecto numquam atque in placeat deleniti! Cum vitae, autem exercitationem voluptatem delectus odio.</p>
                    
                </div>
            </div>
        </div>
        <div class="part2 clear">
        <?php
	     include "inc/sidebar.php";
        ?>
            <!-- <div class="sidebar clear">
                <div class="samesidebar clear">
                    <h2>Latest article</h2>
                   
                    <ul>
                        <li><a href="#">Post Title one will be go here</a></li>
                        <li><a href="#">Post Title two will be go here</a></li>
                        <li><a href="#">Post Title three will be go here</a></li>
                        <li><a href="#">Post Title four will be go here</a></li>
                       
                    </ul>
                </div>
                
            </div>
            <div class="sidebar">
                <div class="samesidebar clear">
                    <h2>Popular airticle</h2>
                    <div class="popular">
                    <h3><a href="post.php">
                        Post title will be go here..</a></h3>
                    <img src="img/1.jpg" alt="post image">
                    <p> lorem ipsum dolor, sit amet consectetur adipisicing elit. Exercitationem voluptates maiores iure vitae nihil id doloribus sint, nesciunt commodi et?</p>
                    </div>

                    <div class="popular">
                        <h3><a href="post.php">
                            Post title will be go here..</a></h3>
                        <img src="img/images.jpeg" alt="post image">
                        <p> lorem ipsum dolor, sit amet consectetur adipisicing elit. Exercitationem voluptates maiores iure vitae nihil id doloribus sint, nesciunt commodi et?</p>
                        </div>

                        <div class="popular">
                            <h3><a href="post.php">
                                Post title will be go here..</a></h3>
                            <img src="img/download.jpg" alt="post image">
                            <p> lorem ipsum dolor, sit amet consectetur adipisicing elit. Exercitationem voluptates maiores iure vitae nihil id doloribus sint, nesciunt commodi et?</p>
                            </div>
                </div>
                
            </div>
            <div class="sidebar">
                <div class="samesidebar clear">
                    <h2>Sidebar one Header</h2>
                    <p> lorem ipsum dolor, sit amet consectetur adipisicing elit. Exercitationem voluptates maiores iure vitae nihil id doloribus sint, nesciunt commodi et?</p>
                </div>
                
            </div> -->
            
        </div>
      </div>
    </div>
    <?php
	include "inc/footer.php";
    ?>
    