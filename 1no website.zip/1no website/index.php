
<?php 
	include "inc/header.php";
?>
<?php
	include "inc/slider.php";
?>
<div class="contentsection clear">
        <div class="part1 clear">
            <div class="maincontent clear">


         <!-- pagination -->
         <?php
         $per_page=3;
         if(isset($_GET["page"])){
            $page=$_GET["page"];
         }else{
            $page=1;
         }
         $start=($page-1) * $per_page;
         ?>
          <!-- pagination -->

            <?php 
                $quiry="select * from post limit  $start,$per_page";
                $post= $db->select( $quiry);
                if($post){
                    while($result=$post->fetch_assoc()){
                ?>

                <div class="samepost clear">
                    <h2><?php echo $result['title'];?></h2>
                    <h4><?php echo $fm->formatDate($result['date']);?>, By <a href="#"><?php echo $result['author'];?></a></h4>
                    <!-- <img src="img/download (2).jpg" alt=""> -->
                    <img src="img/<?php echo $result['image'];?>" alt="">
                    <?php echo $fm->textShort($result['body']);?> 

                    <div class="readmore clear">
                        <a href="post.php?id=<?php echo $result['id'];?>">Read More</a>
                    </div>
                </div>
                <!-- <div class="samepost clear">
                    <h2>Our post title here</h2>
                    <h4>Octobor 12, 2022, 10.00 PM, By <a href="#">Sumaiya</a></h4>
                    <img src="img/images.jpeg" alt="">
                    <p>lorem ipsum dolor, sit amet consectetur adipisicing elit. , fuga recusandae error eveniet alias reprehenderit adipisci! lorem ipsum dolor, sit amet consectetur adipisicing elit., fuga recusandae error eveniet alias reprehenderit adipisci! lorem ipsum dolor, sit amet consectetur adipisicing elit., fuga recusandae error eveniet alias reprehenderit adipisci! lorem ipsum dolor, sit amet consecteturlorem ipsum dolor, sit amet consectetur adipisicing elit. Quidem beatae autem distinctio eum sapiente non ipsam, provident ducimus! </p> 
                    <div class="readmore clear">
                        <a href="post.php">Read More</a>
                    </div>
                </div> -->
              
                <?php }?>
                    <!-- pagination -->
                    <!-- //initial page=1 -->
                    <?php 
                    $quiry="select * from post";
                    $result=$db->select( $quiry);
                    $total_rows=mysqli_num_rows( $result);
                    $total_page=ceil($total_rows/$per_page);
                    ?>
                    <span class='pag'>
                     <?php 
               echo "<span class='pag' style='display: block;font-size: 15px; margin-top: 8px;padding: 10px;text-align: center;'><a href='index.php?page=1'>".'First Page'."</a>";
               for($i=1;$i<= $total_page;$i++){
                echo "<a href='index.php?page=". $i."'>".$i."</a>";
               };
                     echo "<a  href='index.php?page= $total_page'>".'Last Page'."</a></span>"
                     
                     ?>
                <span>
                    <!-- pagination    style='display: block;font-size: 15px; margin-top: 10px;padding: 10px;text-align: center;'-->
            <?php }else{
                echo "not found";
                }?>
            </div>
            
           
        </div>
        <div class="part2 clear">
        <?php
	     include "inc/sidebar.php";
        ?>
        </div>
        
    </div>
    </div>
 
    <?php
	include "inc/footer.php";
    ?>

 