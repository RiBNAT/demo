

  
   
    <?php 
	include "inc/header.php";
?>
<link rel="stylesheet" href="css/grid.css">
    <link rel="stylesheet" href="css/animated-circle.css">
    <link rel="stylesheet" href="css/normalize.css">

    <div class="contentsection clear">
    <div class="part1 clear">
        <section class="skill-section" id="skill">
            <div class="row">
                <h2>we got skill!</h2>
                <p class="little-discription">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                </div>
                <div class="row">
                    <div class="col span_1_of_4 box">
                        <svg class="radial-progress web-design" data-percentage="90" viewBox="0 0 80 80">
                            
                                <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                            
                                <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                            
                                <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">90%</text>
                            
                        </svg>
                        <h3>WEB DESIGN</h3>
                    </div>
                    <div class="col span_1_of_4 box">
                        <svg class="radial-progress html-css" data-percentage="75" viewBox="0 0 80 80">
                            
                                <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                            
                                <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                            
                                <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">75%</text>
                            
                        </svg>
                        <h3>HTML / CSS</h3>
                    </div>
                    <div class="col span_1_of_4 box">
                        <svg class="radial-progress graphic-design" data-percentage="70" viewBox="0 0 80 80">
                            
                                <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                            
                                <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                            
                                <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">70%</text>
                            
                        </svg>
                        <h3>GRAPHIC DESIGN</h3>
                    </div>
                    <div class="col span_1_of_4 box">
                        <svg class="radial-progress ui-ux" data-percentage="85" viewBox="0 0 80 80">
                            
                                <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                            
                                <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                            
                                <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">85%</text>
                            
                        </svg>
                        <h3>UI / UX</h3>
                    </div>
                </div>
           </section>
    </div>
        <div class="part2 clear">
        <?php
	     include "inc/sidebar.php";
        ?>  
        </div>
       </div>
    </div> 
    <?php
	include "inc/footer.php";
    ?>