<?php 
	include "config/config.php";
?>
<?php 
	include "config/format.php";
?>
<?php 
	include "lib/Database.php";
?>
<?php 
$db= new Database() ;
$fm=new Format();
?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="My First Website">
      <meta name="description" content="First PHP Website">
      <meta name="author" content="Sumaiya Akter">

      <?php if(isset($_GET['id'])){

$keywordid=$_GET['id'];
$quiry="select * from post where id='$keywordid'";
$keywords= $db->select($quiry);
if($keywords){
  while($result=$keywords->fetch_assoc()){?>
        <meta name="keywordS" content="<?php echo $result['tags']; ?>">

 <?php }} }else{?>
  <meta name="keywordS" content="<?php echo KEYWORDS; ?>">

 <?php }?>
  
 
      <meta name="keyword" content="blog,cms blog">

      <!-- <link rel="stylesheet" href="my css/style.css">
      <link rel="stylesheet" href="css/index.css"> -->
      <?php include 'scripts/css.php'?>
      <!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>  -->
      <title><?php echo $fm->title();?>-<?php echo TITLE;?></title>
  </head>
  <body style="background: url(img/leaves.png) repeat fixed 0 0;">
  <div class="templete">
      <div class="headersection clear">
          <div class="logo clear">
        <?php 
            $query="select * from name_title where id='1'";
            $header=$db->select($query);
				if($header){								
				while($result=$header->fetch_assoc()){
        ?>
              <img src="img/<?php echo $result['logo'];?>" alt="logo">

              <!-- <h1>WELCOME TO <span><a href="" class="typewrite" data-period="2000" data-type='[  "NANDINE !" ]'>
                <span class="wrap"></span>
              </a></span></h1> -->

              <h2><?php echo $result['name'];?></h2>
              <p><?php echo $result['title'];?><?php echo date('Y');?></p>
              <?php }}?>
          </div>
          <div class="social clear">
              <div class="icon clear">
                  <a href="https://www.google.com"><img src="img/social/facebook.png" alt="google"></a>
                  <a href="https://www.linkedin.com"><img src="img/social/twitter.png" alt="Linkedin"></a>
                  <a href="https://www.gmail.com"><img src="img/social/google.png" alt=""></a>
                  <a href="https://www.facebook.com"><img src="img/social/linkedin.png" alt="Facebook"></a> 
                
              </div>
          </div>
          <div class="searchbtn clear">
              <form action="search.php" method="get">
                  <input type="text" name="search" placeholder="Search keyword..."/>
                  <input type="submit" name="submit" value="Search"/>
              </form>
          </div>
      </div>
      <div class="navsection clear">
        <?php 
        $path=$_SERVER['SCRIPT_FILENAME'];
        $currentpage=basename($path,'.php');
        ?>
          <ul>
              <li><a
              <?php
              if( $currentpage=='index'){
                echo 'id="active"';
              }
              ?>
               href="index.php">Home</a></li>
              <li><a <?php
              if( $currentpage=='About'){
                echo 'id="active"';
              }
              ?>
              <?php 
            //   if(isset($_GET['pageid'])&& $_GET['pageid']==true$result['id']){
            //     echo 'id="active"';
            //   }
              ?>
              
              href="About.php">About Me</a></li>
              
              <li><a
              <?php
              if( $currentpage=='Services'){
                echo 'id="active"';
              }
              ?>
              href="Services.php">Services</a></li>
              <!-- <li><a href="post.php">Post</a> -->
              <li><a <?php
              if( $currentpage=='Skill'){
                echo 'id="active"';
              }
              ?> href="Skill.php">Skill</a>
                
              </li>
              <li><a
              <?php
              if( $currentpage=='contact'){
                echo 'id="active"';
              }
              ?>
              href="contact.php">Contact</a></li>
             
          </ul>
      </div>  