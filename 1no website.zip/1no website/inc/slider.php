<div class="galarycontainer">
        <div class="slideshow">
          <div id="playpausebtn" style=" background-image: url(img/play.png);
          background-repeat: no-repeat;
          background-size: cover" onclick="playpauseSlide()"></div>
          <div class="leftarrow" onclick="plusslide(-1)"><span class="arrow arrowleft"></span></div>
          <div class="rightarrow" onclick="plusslide(1)"><span class="arrow arrowright"></span></div>
          <div class="captionholder" ><p class="text"></p></div>
          <div class="images">
            <img src="img/1.jpg" alt="">
            <p class="caption">Caption text-01</p>
          </div>
          <div class="images">
            <img src="img/download (2).jpg" alt="">
            <p class="caption">Caption text-02</p>
          </div>
          <div class="images">
            <img src="img/slideshow/01.jpg" alt="">
            <p class="caption">Caption text-03</p>
          </div>
          <div class="images">
            <img src="img/slideshow/02.jpg" alt="">
            <p class="caption">Caption text-04</p>
          </div>
          <div class="images">
            <img src="img/slideshow/03.jpg" alt="">
            <p class="caption">Caption text-05</p>
          </div>
      
        </div>
      
      
    </div>