<div class="sidebar clear">
                <div class="samesidebar clear">
                    <h2>Categories</h2>
                    
                    <ul>
                        <?php 
                        $quiry="select * from category" ;
                        $category= $db->select( $quiry);
                        if($category){
                            while($result=$category->fetch_assoc()){
                    ?>
                      <li><a href="posts.php?category=<?php echo $result['id'];?>"><?php echo $result['name'];?></a></li>
                        <?php }} else{?>
                            <li>No Category created</li>
                        <?php }?>
                      
                    </ul>
                </div>
                
        
            <div class="sidebar">
                <div class="samesidebar clear">
                    <h2>Latest Airticle</h2>
                    <?php 
                        $quiry="select * from post  limit 2";
                        $post= $db->select( $quiry);
                        if($post){
                            while($result=$post->fetch_assoc()){
                    ?>
                   <div class="popular">
                        <h3><a href="post.php?id=<?php echo $result['id'];?>"><?php echo $result['title'];?></a></h3>
                        <img src="img/<?php echo $result['image'];?>" alt="">
                        <?php echo $fm->textShort($result['body'],120);?> 
                    </div>
                    <?php }}else{ echo "no related post available";}?> 
                 
                    <!-- <div class="popular">
                        <h3><a href="post.html">
                            Post title will be go here..</a></h3>
                        <img src="img/images.jpeg" alt="post image">
                        <p> lorem ipsum dolor, sit amet consectetur adipisicing elit. Exercitationem voluptates maiores iure vitae nihil id doloribus sint, nesciunt commodi et?</p>
                    </div> -->
                           
                </div>
                 
            </div>
            <div class="sidebar">
                <div class="samesidebar clear">
                    <h2>Popular  Airticle</h2>
                    <?php 
                        $quiry="select * from post  limit 1";
                        $post= $db->select( $quiry);
                        if($post){
                            while($result=$post->fetch_assoc()){
                    ?>
                    <h3><a style="text-decoration:none"href="post.php?id=<?php echo $result['id'];?>"> <?php echo $fm->textShort($result['body'],120);?> </a></h3>
                   
                    <?php }}else{ echo "no related post available";}?> 
                </div>
                
            </div>
            
            <!-- <div class="sidebar">
                <div class="samesidebar clear">
                    <h2>Sidebar one Header</h2>
                    <p> lorem ipsum dolor, sit amet consectetur adipisicing elit. Exercitationem voluptates maiores iure vitae nihil id doloribus sint, nesciunt commodi et?</p>
                </div>
                
            </div> -->