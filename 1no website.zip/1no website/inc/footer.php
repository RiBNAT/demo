
   <div class="footersection clear">
       
       <div class="footsection">
       <?php 
             $query="select * from footer where id='1'";
                $copyright=$db->select($query);
				if($copyright){								
				while($result=$copyright->fetch_assoc()){
                    ?>
           <P>&copy;<?php echo $result['text'];?> || <a href="#">privacy policy</a></P>
           <p class="link"><a href="#">https://www.facebook.me.com</a></p>
           <p>gmail:sumaiya.cse6.bu@gmail.com</p>
           <?php }}?>
       </div>

   </div>
</div>
<script type="text/javascript" src="js/scroll.js"></script>
<script type="text/javascript" src="js/index.js"></script>
<script  src="js/typed.min.js" type="text/javascript"></script>



</body>
</html>