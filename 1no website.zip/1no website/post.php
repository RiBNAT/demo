
    <?php 
	include "inc/header.php";
?>
    <?php 
	if(!isset($_GET['id']) || $_GET['id']==NULL){
        header("location:404.php");
    }else{
        $id=$_GET['id'];
    }
    // $id=$_GET['id'];
?>
    <div class="contentsection clear">
        <div class="part1 clear">
            <div class="maincontent clear">
                <div class="about">
                <?php 
                $quiry="select * from post where id=$id";
                $post= $db->select( $quiry);
                if($post){
                    while($result=$post->fetch_assoc()){
                ?>
                    <h2><?php echo $result['title'];?></h2>
                    <h4><?php echo $fm->formatDate($result['date']);?>, By <a href="#"><?php echo $result['author'];?></a></h4>
                    <img src="img/<?php echo $result['image'];?>" alt="">
                    <?php echo $result['body'];?>
                    <!-- <p>About me...Lorem, ipsum dolor sit amet consectetur adipisicing elit. Cupiditate, ipsa illo suscipit nemo saepe error hic optio mollitia ducimus magni animi quia vero, sint veritatis consectetur laboriosam dolorum! Molestiae reiciendis molestias, magni facere eos incidunt veritatis nemo saepe rerum dolorem expedita itaque delectus mollitia libero repellat excepturi magnam temporibus officia.</p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt ipsam placeat corporis voluptas soluta, qui dolor. Iste cupiditate nisi corrupti. Aliquid illo ea nostrum ipsa, ipsum aut rem impedit consequatur eligendi harum dolorem possimus ab eveniet temporibus, architecto numquam atque in placeat deleniti! Cum vitae, autem exercitationem voluptatem delectus odio.</p>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ipsam praesentium nemo, iusto fuga omnis dolorem quos. Optio, minima assumenda. Sed iste sequi voluptas officiis iusto similique animi cupiditate, repellat porro quos et neque quam vitae perferendis, aperiam cum assumenda dolor at deserunt deleniti fugiat excepturi? Possimus harum ab sequi sint?</p> -->
                 
                    <div class="relatedpost">
                        <h2>Related articles</h2>
                        
                        <?php 
                            $catid= $result['cat_id'];
                            $quiry_cat="select * from post where cat_id= '$catid' limit 6";
                            $relatedpost= $db->select( $quiry_cat);
                            if($relatedpost){
                                while($result=$relatedpost->fetch_assoc()){
                            ?>
                    
                <div class="grid">
                           
                        <a href="post.php?id=<?php echo $result['id'];?>"><img  src="img/<?php echo $result['image'];?>" alt="post image"></a>
                     
                        <!-- <a href="#"><img src="img/1.jpg" alt="post image"></a>
                        <a href="#"><img src="img/1.jpg" alt="post image"></a>
                        <a href="#"><img src="img/1.jpg" alt="post image"></a>
                        <a href="#"><img src="img/1.jpg" alt="post image"></a>
                        <a href="#"><img src="img/1.jpg" alt="post image"></a>
                        <a href="#"><img src="img/1.jpg" alt="post image"></a> -->
                        </div>
                    <?php }}else{ echo "no related post available";}?>
                    </div>
               
                <?php } }else{
                header("location:404.php");
                }?>
                
                </div>
            </div>
        </div>
        <div class="part2 clear">
        <?php
	     include "inc/sidebar.php";
        ?>    
        </div> 
    </div>
    </div>
    <?php
	include "inc/footer.php";
    ?>