<?php 
	include "inc/header.php";
?>
 <link rel="stylesheet" href="css/grid.css">
    <div class="contentsection clear">
    <div class="part1 clear">
        <section class="services-section js--services-section" id="service">
            <div class="row">
                <h2>services we provide</h2>
                <p class="little-discription">we are working with both individuals and business from all over the glove to creat awesome websites and aplications.</p>
            </div>
                <div class="row">
                    <div class="col span_1_of_4 box">
                       <img src="img/flag.png" alt="flag" class="services-icon">
                       <h3>Branding</h3>
                       <p>Lorem ipsum dolor sit amet consectetuer adipiscing elit, sed diam nonummy nibth.</p>
                    </div>
                    <div class="col span_1_of_4 box">
                       <img src="img/crayon.png" alt="crayon" class="services-icon">
                       <h3>Design</h3>
                       <p>Sed ut perspiciatis unde omits iste natus error sit voluptatem lore ipsum.</p>
                    </div>
                    <div class="col span_1_of_4 box">
                       <img src="img/gears.png" alt="gears" class="services-icon">
                       <h3>Development</h3>
                       <p>At vero eos et accusamuset iusto odio diginissimos qui blanditiis presentium.</p>
                    </div>
                    <div class="col span_1_of_4 box">
                       <img src="img/rocket.png" alt="rocket" class="services-icon">
                       <h3>Rocket science</h3>
                       <p>Et harum uidem est et expedita distinctio,Nam libero tempore lorem ipsum.</p>
                    </div>
                
            </div>
        </section>
    </div>
        <div class="part2 clear">
        <?php
	     include "inc/sidebar.php";
        ?>
        </div>
       </div>
    </div> 
    <?php
	include "inc/footer.php";
    ?>