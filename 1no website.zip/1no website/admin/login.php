<?php 
	include "../lib/Session.php";
	Session::checkLogin();
?>
<?php 
	include "../config/config.php";
?>
<?php 
	include "../config/format.php";
?>
<?php 
	include "../lib/Database.php";
?>
<?php 
$db= new Database() ;
$fm=new Format();
?>

<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Login</title>
    <link rel="stylesheet" type="text/css" href="css/stylelogin.css" media="screen" />
</head>
<style>
    form input[type="email"]{
        background: #eae7e7 ;
	border: 1px solid #c8c8c8;
	color: #777;
	font: 20px Helvetica, Arial, sans-serif;
	margin: 0 0 10px;
	padding: 15px 10px 15px 40px;
	width: 80%;
    }
    form input[type="email"]:focus{
        background-color: #fff;
        box-shadow: 0 0 2px #ed1c24 inset;
	border: 1px solid #ed1c24;
	outline: none;
    }
	
</style>
<body>
<div class="container">
	<section id="content">
		<?php 
		if($_SERVER['REQUEST_METHOD']=='POST'){
			$useremail=$fm->validation($_POST['useremail']);
			$password=$fm->validation($_POST['password']);//user=sumaiya,pass=1234
			// $password=$fm->validation(md5($_POST['password']));//user=sumi,pass=1234
			$useremail=mysqli_real_escape_string($db->link,$useremail);
			$password=mysqli_real_escape_string($db->link,$password);
			$quiry="SELECT * FROM user Where email='$useremail' AND password='$password'";
			$result= $db->select( $quiry);
			if($result!=false){
				$value=mysqli_fetch_array($result);
				$row=mysqli_num_rows($result);
				if($row>0){
					Session::set("login",true);
					Session::set("useremail",$value['useremail']);
					Session::set("name",$value['name']);
					Session::set("userId",$value['id']);
					Session::set("userRole",$value['role']);
					// Session::set("userId",$result['id']);
					header("Location:index.php");
				}else{
					echo "<span style='color:red;font-size:18px;'>No Result Found!!</span>";
				}
			}
			else{
				echo "<span style='color:red;font-size:18px;'>Email or Password are not matched!!</span>";
			}
		}
		?>
		<form action="login.php " method="post">
			<h1>Admin Login</h1>
			<div>
				<input type="email" placeholder="UserEmail" required="" name="useremail"/>
			</div>
			<div>
				<input type="password" placeholder="Password" required="" name="password"/>
			</div>
			<div>
				<input type="submit" value="Log in" />
			</div>
			<div>
				<h2><a href="signup.php">SignUp</a></h2>
			</div>
		</form><!-- form -->
		<div class="button">
			<a href="forgotpass.php">Forgot Password !</a>
		</div>
	</section><!-- content -->
</div><!-- container -->
</body>
</html>
