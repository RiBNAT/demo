<?php include'inc/header.php'?>
<?php include'inc/sidebar.php'?>
<?php if(Session::get('userRole')!=='Admin'){
    echo "<script> window.location='index.php';</script>";
    //header("Location:index.php");
}   
    ?>


        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New User</h2>
               <div class="block copyblock"> 
                <?php 
                    if($_SERVER['REQUEST_METHOD']=='POST'){
                        $username=$fm->validation($_POST['username']);
                        $useremail=$fm->validation($_POST['email']);
                        $userpassword=$fm->validation($_POST['password']);
                        $userrole=$fm->validation($_POST['role']);

                        
                        $username=mysqli_real_escape_string($db->link,$username);
                        $useremail=mysqli_real_escape_string($db->link,$useremail);

                        $userpassword=mysqli_real_escape_string($db->link,$userpassword);

                        $userrole=mysqli_real_escape_string($db->link,$userrole);

                        //$password=mysqli_real_escape_string($db->link,$password);
                        if(empty($username)||empty($userpassword)||empty($userrole)||empty($useremail)){
                            echo "<span class='error'>Field must not be empty !</span>";
                        }else{
                            $mailquiry="select * from user where email='$useremail' limit 1";
                             $mailcheck=$db->select($mailquiry);
                             if($mailcheck==true){
                                echo "<span class='error'>Email Already Exists...</span>";
                             }else{
                            $quiry="INSERT INTO user(name,email,password,role) values('$username','$useremail','$userpassword','$userrole') ";
                            $catupdate=$db->update($quiry);
                            if($catupdate){
                                echo "<span class='success'>User Created  Successfully.</span>";
                            }else{
                                echo "<span class='error'>User Not Updated.</span>";
                            }
                        }
                    }
                    }
                ?>
                <?php 
                    // $quiry="select * from category where id='$id' order by id asc";
                    // $category=$db->select($quiry);
                    // while($result=$category->fetch_assoc()){

                ?>
                 <form action="" method="post">
                    <table class="form">					
                        <tr>
                            <td>
                                <label for="">Username</label>
                            </td>
                            <td>
                                <input type="text" name="username" placeholder="Enter your user name.." class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="">Email</label>
                            </td>
                            <td>
                                <input type="text" name="email" placeholder="Enter valid Email Address.." class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="">Password</label>
                            </td>
                            <td>
                                <input type="text" name="password" placeholder="Enter your Password.." class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="">User Role</label>
                            </td>
                            <td>
                                <select name="role" id="select">
                                    <option value="">Select User Role</option>
                                    <option value="Admin">Admin</option>
                                    <option value="Author">Author</option>
                                    <option value="Editor">Editor</option>
                                </select>
                            </td>
                        </tr>
						<tr> 
                            <td>

                            </td>
                            <td>
                                <input type="submit" name="submit" Value="Create" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <!-- <?php ?> -->
                </div>
            </div>
        </div>
 <?php include'inc/footer.php';?>