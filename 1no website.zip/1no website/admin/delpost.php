<?php 
	include "../lib/Session.php";
	Session::check();
?>
<?php 
	include "../config/config.php";
?>
<?php 
	include "../config/format.php";
?>
<?php 
	include "../lib/Database.php";
?>
<?php 
$db= new Database() ;
?>
<?php
if(!isset($_GET['delid']) || $_GET['delid']==NULL){
    header("Location:postlist.php");
}else{
    $postid=$_GET['delid'];
    $query="select * from post where id=' $postid'";
    $get_data =$db->select($query);
             if ($get_data) {
             while($delimg=$get_data->fetch_assoc()){
                $dellink=$delimg['image'];
                unlink($dellink);
             }
       }

       $delquiry="delete from post where id='$postid'";
       $del_data =$db->delete($delquiry);
       if($del_data){
       
       echo "<script>alert(Data Deleted Successfully);</script>";
         header("Location:postlist.php");
       }else{
        echo "<script>alert(Data is not deleted);</script>";
        header("Location:postlist.php");
       }
}

?>