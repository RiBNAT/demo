<?php 
	include "../lib/Session.php";
	Session::check();
?>
<?php 
	include "../config/config.php";
?>

<?php 
	include "../lib/Database.php";
?>
<?php 
$db= new Database() ;
?>
<?php
if(!isset($_GET['delid']) || $_GET['delid']==NULL){
    header("Location:index.php");
}else{
    $pageid=$_GET['delid'];
   

       $delquiry="delete from page where id='$pageid'";
       $del_data =$db->delete($delquiry);
       if($del_data){
       
       echo "<script>alert('Page Deleted Successfully.');</script>";
       echo "<script>window.location='index.php';</script>";
        //  header("Location:index.php ");
       }else{
        echo "<script>alert('Page is not deleted');</script>";
        header("Location:index.php");
       }
}

?>