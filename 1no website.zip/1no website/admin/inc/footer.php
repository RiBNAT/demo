<div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info">
        <p>
         &copy; Copyright <a href="">sumaiya.cse6.bu@gmail.com</a>. Barisal University.
        </p>
    </div>
</body>
</html>