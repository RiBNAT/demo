<?php 
	// include "../lib/Session.php";
	// Session::checkLogin();
?>
<?php 
	include "../config/config.php";
?>
<?php 
	include "../config/format.php";
?>
<?php 
	include "../lib/Database.php";
?>
<?php 
 $db= new Database() ;
 $fm=new Format();


 if(isset($_POST['signup'])){
    
    $name=mysqli_real_escape_string($db->link, $_POST['username']);
    $email=mysqli_real_escape_string($db->link, $_POST['useremail']);
    $password=mysqli_real_escape_string($db->link, $_POST['password']);

    $check_quiry="select * from user where email='$email'";
	$result= $db->select( $check_quiry);
			if($result==false){
				$query="INSERT INTO user(name,email,password) values('$name','$email','$password')";
				$re=mysqli_query($db->link, $query);
				if($re){
					echo "<script>alert(SignUp Successfully..Now Again Login using Information..);</script>";
				   header('Location:login.php');
				}
			}
}
?>

<?php
// if(isset($_POST(['Signup']))){
// 	$name=mysqli_real_escape_string($db, $_POST['name']);
// 	$email=mysqli_real_escape_string($db, $_POST['email']);
// 	$password=mysqli_real_escape_string($db, $_POST['password']);
// 	$check_query="select * from user where email='$email'";
// 	$result=mysqli_query($db,$check_query);
// 	$users=mysqli_fetch_assoc($result);
// 	$i=0;
// 	if($users){
// 		$i=1;
// 	}
// 	if($i==0){
// 		$query="insert into user(name,email,password) values('$name','$email','$password')";
// 		$re=mysqli_query($db, $query);
//         if($re){
//            header('Location:login.php');
//         }
// 	}
// }
?>

<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>SignUp</title>
    <link rel="stylesheet" type="text/css" href="css/stylelogin.css" media="screen" />
</head>
<style>
    form input[type="email"]{
        background: #eae7e7 ;
	border: 1px solid #c8c8c8;
	color: #777;
	font: 20px Helvetica, Arial, sans-serif;
	margin: 0 0 10px;
	padding: 15px 10px 15px 40px;
	width: 80%;
    }
    form input[type="email"]:focus{
        background-color: #fff;
        box-shadow: 0 0 2px #ed1c24 inset;
	border: 1px solid #ed1c24;
	outline: none;
    }
</style>
<body>
<div class="container">
	<section id="content">
		
			
		<form action=" " method="post">
			<h1>SignUp</h1>
			<div>
				<input type="text" placeholder="Username" required="" name="username"/>
			</div>
            <div>
				<input type="email" placeholder="Useremail" required="" name="useremail"/>
			</div>
			<div>
				<input type="password" placeholder="Password" required="" name="password"/>
			</div>
			<div>
				<input type="submit" name="signup" value="SignUp" />

                <h6 class="mt-4"><a href="login.php">Already have account? Login</a></h6>

			</div>
		</form><!-- form -->
		<!-- <div class="button">
			<a href="#">Training with live project</a>
		</div> -->
	</section><!-- content -->
</div><!-- container -->
</body>
</html>
