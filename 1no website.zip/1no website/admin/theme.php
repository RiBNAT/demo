<?php include'inc/header.php'?>
<?php include'inc/sidebar.php'?>


        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Themes</h2>
               <div class="block copyblock"> 
                <?php 
                    if($_SERVER['REQUEST_METHOD']=='POST'){
                        $theme=$_POST['theme'];
                        $theme=mysqli_real_escape_string($db->link, $theme);
                            $quiry="UPDATE theme SET theme='$theme' where id='1'";
                            $updated_row=$db->update($quiry);
                            if($updated_row){
                                echo "<span class='success'>Theme  Updated Successfully.</span>";
                            }else{
                                echo "<span class='error'>Theme is Not Updated!!</span>";
                            }
                        
                    }
                ?>
                 <?php 
                    $quiry="SELECT * FROM theme WHERE id='1'";
                    $themes=$db->select($quiry);
                    while($result=$themes->fetch_assoc()){

                ?>
                 <form action="" method="post">
              
                    <table class="form">					
                        <tr>
                            <td>
                                <input <?php if($result['theme'] == "default")
                                {
                                    echo "checked";
                               }
                                   ?> type="radio"  name="theme" value="default">Default
                                
                            </td>
                            <td>
                                
                                <input type="submit" Value=" <?php echo $result['theme'];?>" />

                            </td>
                           
                            
                        </tr>
                        <tr>
                            <td>
                            <input <?php if($result['theme']=='theme1')
                                {
                                    echo "checked";
                                 }
                                   ?> type="radio"  name="theme" value="theme1">Theme1(green)
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <input  <?php if($result['theme']=='theme2')
                                {
                                    echo "checked";
                                 }
                                   ?> type="radio" name="theme" value="theme2">Theme2(blue)
                            </td>
                        </tr>
                       
						<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Change" />
                            </td>
                        </tr>
                    </table>
                 
                    </form>
                    <?php }?>
                </div>
            </div>
        </div>
 <?php include'inc/footer.php';?>