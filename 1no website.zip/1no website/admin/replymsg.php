<?php include'inc/header.php';?>
<?php include'inc/sidebar.php';?>
<?php 
if(!isset($_GET['msgid']) || $_GET['msgid']==NULL){
    // header("Location:inbox.php");
    echo "<script>window.location='inbox.php';</script>";
}else{
    $id=$_GET['msgid'];
}
?>

        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>View Message</h2>
                <?php 
                if($_SERVER['REQUEST_METHOD']=='POST'){
                    $toemail=$fm->validation($_POST['toemail']);
                    $fromemail=$fm->validation($_POST['fromemail']);
                    $subject=$fm->validation($_POST['subject']);
                    $message=$fm->validation($_POST['message']);
                    $sendmessage=mail($toemail,$subject,$message,$fromemail);
                    if($sendmessage){
                        echo "<span class='success'>Message Sent Successfully. </span>";
                        }else{
                    echo "<span class='error'>Something Went Wrong!</span>";
                   
                    }
                }
                
                ?>
                <div class="block">               
                 <form action="" method="post">

                        <?php 
							$quiry="select * from contact where  id='$id'";
							$contact=$db->select($quiry);
							if($contact){

								while($result=$contact->fetch_assoc()){
					
						?>
                    <table class="form">
                 
                        <tr>
                            <td>
                                <label>To</label>
                            </td>
                            <td>
                                <input type="text" readonly name="toemail" value="<?php echo $result['email']?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>From</label>
                            </td>
                            <td>
                                <input type="text" name="fromemail" placeholder="Please Enter your Email Address" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Subject</label>
                            </td>
                            <td>
                            <input type="text" name="subject" placeholder="Subject" class="medium" />
                            </td>
                        </tr>
                        
                        <tr>
                            <td >
                                <label>Message</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name="message" placeholder="Write some Text..."></textarea>
                            </td>
                        </tr>
                        
                        
                       
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="send" Value="Send" />
                            </td>
                        </tr>
                    </table>
                    <?php }}?>
                    </form>
                </div>
            </div>
        </div>
<!-- //load tinyMCE -->
<script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
</script>
<!-- //load tinyMCE -->
<?php include'inc/footer.php';?>

