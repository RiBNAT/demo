
    <?php 
	include "inc/header.php";
?>
<?php 
		if($_SERVER['REQUEST_METHOD']=='POST'){
			$fname=$fm->validation($_POST['firstname']);
			$lname=$fm->validation($_POST['lastname']);
            $email=$fm->validation($_POST['email']);
            $text=$fm->validation($_POST['body']);
            
			$fname=mysqli_real_escape_string($db->link,$fname);
            $lname=mysqli_real_escape_string($db->link,$lname);
            $email=mysqli_real_escape_string($db->link,$email);
            $text=mysqli_real_escape_string($db->link,$text);


            $query = "INSERT INTO contact(firstname,lastname,email,text) VALUES('$fname','$lname','$email','$text')";
            $inserted_rows = $db->insert($query);
            if ($inserted_rows) {
                echo "<span style='color:green'>Successfully send..</span>";
            }else{
        echo "<span style='color:red'>Message not be sent!</span>";
       }

            // $error="";
            // if(empty($fname)){
            //     $error="Firstname field must not be empty!";
            // }elseif(empty($lname)){
            //     $error="lastname field must not be empty!";
            // }elseif(empty($email)){
            //     $error="Email field must not be empty!";
            // }
            // elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){
            //     $error="Invalied Email Address!";
            // }else{
            //     echo "<span style='color:green'>Successfully send..</span>";
            // }
        }
            ?>
    <div class="contentsection clear">
        <div class="part1 clear">
            <div class="maincontent clear">
                <div class="contact">
                    <h2>Contact Us</h2>
                    <?php
                    // if(isset($error)){
                    //     echo "<span style='color:red'>$error</span>";
                    // }
                    ?>
                    <form action="" method="post">
                   
                    
                    <label class="s" for="firstname">Your first name:</label>
                    <input type="text" name="firstname" placeholder="Enter your firstname" required>
                    <label class="s" for="lastname">Your last name:</label>
                    <input type="text" name="lastname" placeholder="Enter your lastname"required>
                    <label class="s" for="email">Your email address:</label>
                    <input type="email" name="email" placeholder="Enter your Email Address"required>
                    <label class="s" for="address">Your address:</label>
                   <textarea name="body" id="" cols="30" rows="10"></textarea>
                    <input type="submit" name="submit" value="Send">
                </form>
                </div>
            </div>
        </div>
        <div class="part2 clear">
            
              
            <?php
	     include "inc/sidebar.php";
        ?>
        </div>
       </div>
    </div>
    <?php
	include "inc/footer.php";
    ?>