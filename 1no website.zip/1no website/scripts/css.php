<link rel="stylesheet" href="my css/style.css">
<link rel="stylesheet" href="css/index.css">


    <?php 
        $quiry="select * from theme where id='1'";
        $themes=$db->select($quiry);
        while($result=$themes->fetch_assoc()){
            if($result['theme']=='default'){?>
<link rel="stylesheet" href="theme/default.css">
<?php }elseif($result['theme']=='theme1'){?>
    <link rel="stylesheet" href="theme/theme1.css">
<?php }elseif($result['theme']=='theme2'){?>
    <link rel="stylesheet" href="theme/theme2.css">
  <?php } }?>

<!-- <style>
    .headersection{
    background-color:#222222;
}
.icon a {
/* background: #a56e0a none repeat scroll 0 0; */
background-color: #222222;   
}
.searchbtn input[type="text"] {
border: 1px solid #A56E0A;
padding: 10px;
background: #FFE07C;
}
.searchbtn input[type="submit"] {
border: 1px solid #9d6602;
}
input[type="submit"]{
cursor: pointer;
border: 1px solid #e6af4b;
background-color: #B7801C;
}
.navsection{
background-color: #e6a44d;
color:#ddd;
}
.navsection ul li a{

background-color: #b4790b; 
border: 1px solid #a86e04;
color: #fff;
}
.navsection ul li a:hover{
background-color: #2F2D2E;
color: #FFF;
}
.navsection ul li a:hover{
background-color: #2F2D2E;
color: #FFF;
}
.samepost h2, .about h2, .contact h2{
border-bottom: 2px solid #878016;
color:#e6a44d;
}
.part2{
background-color: #e6a44d; 
}
.samesidebar ul li a{
color:#814a00;
}
.readmore a{
color: #333;
border: 2px solid #878016 ;
background-color: rgb(246, 150, 7);

}
.samesidebar h2{
background-color: #334431;
color:#fff;
border-bottom: 2px solid #555555;
}
.maincontent span .pag a{
background-color: #e6af4b;
border:1px solid #a7700c;
color:#333;
border-radius: 3px;
}
.skill-section{
background:linear-gradient(rgb(255,255,255,.9),rgba(251, 163, 1, 0.9)),url(img/restaurant.png);
}
.relatedpost h2{
background: #e6af4b;
color:#000 !important;
border-bottom: 2px solid #B7801C;
}
#active{
background-color: #FEF4E5;
color: #333;
}
.footersection{
background-color: #334431;
}

/* green */
.headersection,.footersection{      
    background-color:#007000;
}
.icon a {
background-color: #2d9d2d;   
}
.searchbtn input[type="text"] {
border: 1px solid #034703;
padding: 10px;
background: #52c252;
}
.searchbtn input[type="submit"] {
border: 1px solid #007000;
}
input[type="submit"]{
border: 1px solid #e6af4b;
background-color: #005600;
}
.navsection{
background-color: #35a535;
color:#ddd;
}
.navsection ul li a{

background-color: #025d02; 
border: 1px solid #007000;
color: #fff;
}
.navsection ul li a:hover{
background: #b7801c none repeat scroll 0 0;
  border: 1px solid #e6af4b;
  color:#fff;
}
.samepost h2, .about h2, .contact h2{
border-bottom: 2px solid #878016;
color:#007000;
}
.part2{
background-color: #35a535;
}
.samesidebar ul li a{
color:#ddd;
font-weight:600;
}
.readmore a{
color: #fff;
border: 2px solid #878016 ;
background-color: #007000;

}
.samesidebar h2{
background-color: #007000;
color:#fff;
border-bottom: 3px solid #343333;
}
.maincontent span .pag a{
background-color: #35a535;
border:1px solid #007000;
color:#333;
border-radius: 3px;
}
.skill-section{
background:linear-gradient(rgb(255,255,255,.9),rgba(60, 189, 10, 0.9)),url(img/restaurant.png);
}
.relatedpost h2{
background: #35a535;
color:#fff !important;
border-bottom: 3px solid #007000;
}
#active{
background-color:#FFB60D;
color: #333;
}
</style> -->
